import requests
import json
from datetime import datetime

API_KEY = "9ebedcf89b1e4fcd986170212250605"  # Замініть на ваш API ключ
BASE_URL = "http://api.weatherapi.com/v1"

def get_weather(city):
    """Отримати поточну погоду для вказаного міста"""
    
    endpoint = f"{BASE_URL}/current.json"
    params = {
        "key": API_KEY,
        "q": city,
        "lang": "uk"  # Українська мова для відповіді
    }
    
    try:
        response = requests.get(endpoint, params=params)
        response.raise_for_status()
        weather_data = response.json()
        
        # Отримуємо потрібні дані
        location = weather_data['location']
        current = weather_data['current']
        
        # Форматуємо вивід
        print(f"\nПогода в місті {location['name']}, {location['country']}")
        print(f"Час: {current['last_updated']}")
        print(f"Температура: {current['temp_c']}°C")
        print(f"Відчувається як: {current['feelslike_c']}°C")
        print(f"Умови: {current['condition']['text']}")
        print(f"Вологість: {current['humidity']}%")
        print(f"Швидкість вітру: {current['wind_kph']} км/год")
        
    except requests.exceptions.RequestException as e:
        print(f"Помилка при отриманні даних: {e}")
    except KeyError as e:
        print(f"Помилка при обробці даних: {e}")

def main():
    while True:
        city = input("\nВведіть назву міста (або 'вихід' для завершення): ")
        
        if city.lower() in ['вихід', 'exit', 'quit']:
            print("Дякуємо за використання програми!")
            break
            
        get_weather(city)

if __name__ == "__main__":
    main()

